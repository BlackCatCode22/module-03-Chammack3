package mystudent;

public class Student {
    String firstName;
    String lastName;
    double gpa;
    String major;
    int age;
    boolean onProbation;

}
