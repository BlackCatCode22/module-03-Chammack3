package mystudent;
public class App {
    public static void main(String [] args) {

        Student myStudent = new Student();
        myStudent.firstName = "Chuck";
        myStudent.lastName = "Dee";
        myStudent.major = "Computer Science";
        myStudent.gpa = 2.2;
        myStudent.age = 25;
        myStudent.onProbation = false;

        Student myStudent2 = new Student();
        myStudent2.firstName = "Holly";
        myStudent2.lastName = "Hatchet";
        myStudent2.major = "None";
        myStudent2.gpa = 2.1;
        myStudent2.age = 27;
        myStudent2.onProbation = true;


        System.out.println(myStudent.firstName);
      //or second student
        System.out.println(myStudent2.age);

    }
}
