package mystuff;
public class Driver {
    public static void main(String[] args) {

        Computer myComputer = new Computer();

        myComputer.company = "Apple Inc.";

        myComputer.model = "Macbook Pro 13 inch";

        myComputer.year = "2020";

        myComputer.age = 4;

        myComputer.developer = true;

        System.out.println(myComputer.year);
    }
}
