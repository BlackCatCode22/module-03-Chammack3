package mystuff;
public class Computer {
    String company;
    String model;
    String year;
    int age;
    boolean developer;
}

